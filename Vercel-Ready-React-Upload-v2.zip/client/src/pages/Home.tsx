import AudioMasteringApp from "@/components/AudioMasteringApp";

export default function Home() {
  return <AudioMasteringApp />;
}
